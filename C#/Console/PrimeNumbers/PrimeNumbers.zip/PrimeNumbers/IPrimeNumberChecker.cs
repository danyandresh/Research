﻿
namespace PrimeNumbers
{
    public interface IPrimeNumberChecker
    {
        bool IsPrime(int number);
    }
}
